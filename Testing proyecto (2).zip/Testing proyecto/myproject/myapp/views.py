from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import AuthenticationForm
from .forms import SignUpForm, PedidoForm
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import Producto, Abastecimiento, Factura, DetalleFactura, Proveedor
from django.utils import timezone
import datetime
from django.shortcuts import get_object_or_404
from .models import DetalleFactura



def register(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('home') 
    else:
        form = SignUpForm()
    return render(request, 'registration/register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('lista_productos')  
    else:
        form = AuthenticationForm()
    return render(request, 'registration/login.html', {'form': form})

def home(request):
    return render(request, 'myapp/home.html')

def lista_productos(request):
    productos = Producto.objects.all()
    return render(request, 'myapp/lista_productos.html', {'productos': productos})

@login_required
@login_required
def hacer_pedido(request):
    if request.method == 'POST':
        proveedor_id = request.POST.get('proveedor')
        producto_id = request.POST.get('productos')
        
        if not proveedor_id or not producto_id:
            return render(request, 'error_template.html', {'error': 'Proveedor o Producto no especificado'})

        try:
            proveedor_id = int(proveedor_id)
            producto_id = int(producto_id)
        except ValueError:
            return render(request, 'error_template.html', {'error': 'ID de proveedor o producto no válido'})

        proveedor = get_object_or_404(Proveedor, id=proveedor_id)
        producto = get_object_or_404(Producto, id=producto_id)
        
        # Aquí deberías crear la factura
        factura = Factura.objects.create(proveedor=proveedor, fecha_emision=datetime.date.today(), total=0) # type: ignore
        
        # Luego de crear la factura, puedes pasar su ID a la función factura_detalle
        return factura_detalle(request, factura_id=factura.id)  # Solo pasamos request y factura_id
    
    form = PedidoForm()  # Assuming you have a form for Pedido
    return render(request, 'myapp/hacer_pedido.html', {'form': form})


@login_required
def factura_detalle(request, factura_id):
    factura = get_object_or_404(Factura, id=factura_id)
    detalles = DetalleFactura.objects.filter(factura=factura)
    return render(request, 'myapp/factura_detalle.html', {'factura': factura, 'detalles': detalles})
