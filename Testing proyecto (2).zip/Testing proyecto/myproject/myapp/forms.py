from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from .models import Proveedor, Producto

class SignUpForm(UserCreationForm):
    email = forms.EmailField(max_length=200, help_text='Required')

    class Meta:
        model = User
        fields = ('username', 'email', 'password1', 'password2')

class PedidoForm(forms.Form):
    proveedor = forms.ModelChoiceField(queryset=Proveedor.objects.all())
    productos = forms.ModelMultipleChoiceField(queryset=Producto.objects.all(), widget=forms.CheckboxSelectMultiple)
    cantidades = forms.CharField(widget=forms.Textarea, help_text="Introduce las cantidades separadas por comas en el mismo orden que los productos seleccionados")

    def clean(self):
        cleaned_data = super().clean()
        productos = cleaned_data.get('productos')
        cantidades = cleaned_data.get('cantidades')

        if productos and cantidades:
            cantidades_list = cantidades.split(',')
            if len(productos) != len(cantidades_list):
                raise forms.ValidationError("El número de productos seleccionados debe coincidir con el número de cantidades proporcionadas.")
            
            try:
                cantidades_list = [int(cantidad) for cantidad in cantidades_list]
            except ValueError:
                raise forms.ValidationError("Todas las cantidades deben ser números enteros.")

            if any(cantidad < 1 or cantidad > 100 for cantidad in cantidades_list):
                raise forms.ValidationError("Cada cantidad debe ser un número entre 1 y 100.")

            cleaned_data['cantidades'] = cantidades_list
        
        return cleaned_data
